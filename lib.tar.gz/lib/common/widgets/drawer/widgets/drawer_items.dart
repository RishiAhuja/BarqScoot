import 'package:escooter/common/router/app_router.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class AppDrawerItems extends StatelessWidget {
  const AppDrawerItems({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      children: [
        // ListTile(
        //   leading: const Icon(Icons.home),
        //   title: const Text('Home'),
        //   onTap: () => Navigator.pop(context),
        // ),
        // ListTile(
        //   leading: const Icon(Icons.history),
        //   title: const Text('Ride History'),
        //   onTap: () {
        //     Navigator.pop(context);
        //     context.push(AppPaths.rideHistory);
        //   },
        // ),
        // ListTile(
        //   leading: const Icon(Icons.account_balance_wallet),
        //   title: const Text('Wallet'),
        //   onTap: () {
        //     Navigator.pop(context);
        //     context.push(AppPaths.wallet);
        //   },
        // ),
        ListTile(
          leading: const Icon(Icons.help),
          title: const Text('Help & Support'),
          onTap: () {
            // TODO: Implement help & support
          },
        ),
        // const Divider(),
        ListTile(
          leading: const Icon(Icons.settings),
          title: const Text('Settings'),
          onTap: () {
            Navigator.pop(context);
            context.push(AppPaths.profile);
          },
        ),
      ],
    );
  }
}
