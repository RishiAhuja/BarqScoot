class AppConstants {
  static const String packageName = 'Fcom.example.escooter';
  static const String DEBUG_TAG = "ESCOOTER";
}
