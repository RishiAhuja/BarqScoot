class ServiceConstants {
  static const String MAPBOX_TOKEN =
      'pk.eyJ1IjoiZGF2aW5kZXIxNDM2IiwiYSI6ImNtNmh5bWpxaTAyeHgycXNoa3M5Mmg1N2gifQ.z2lT6pQZZntilXV90lz4aw';
}
