class SharedPrefsConstants {
  static const themeModeKey = 'theme_mode';
  static const languageKey = 'language_code';
}
