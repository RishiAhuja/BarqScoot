import 'package:flutter/material.dart';

class AppColors {
  static const primaryTeal = Color.fromARGB(255, 0, 128, 128);
  static const backgroundColor = Colors.white;
}
