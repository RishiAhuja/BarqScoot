// dart format width=80
// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i174;
import 'package:http/http.dart' as _i519;
import 'package:injectable/injectable.dart' as _i526;

import '../../../features/auth/data/repository/auth_repository_impl.dart'
    as _i67;
import '../../../features/auth/data/sources/auth_service.dart' as _i780;
import '../../../features/auth/domain/repository/auth_repository.dart' as _i754;
import '../../../features/auth/domain/usecases/register_user_usecase.dart'
    as _i635;
import '../../../features/auth/domain/usecases/sent_otp_usecase.dart' as _i591;
import '../../../features/auth/presentation/providers/auth_providers.dart'
    as _i832;
import '../modules/network_module.dart' as _i184;

extension GetItInjectableX on _i174.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i174.GetIt init({
    String? environment,
    _i526.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i526.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    final networkModule = _$NetworkModule();
    gh.singleton<_i519.Client>(
      () => networkModule.httpClient,
      instanceName: 'httpClient',
    );
    gh.factory<_i780.AuthApiService>(
      () => _i780.AuthApiService(gh<_i519.Client>(instanceName: 'httpClient')),
      instanceName: 'authApiService',
    );
    gh.factory<_i754.AuthRepository>(() => _i67.AuthRepositoryImpl(
        gh<_i780.AuthApiService>(instanceName: 'authApiService')));
    gh.factory<_i591.SendOtpUseCase>(
        () => _i591.SendOtpUseCase(gh<_i754.AuthRepository>()));
    gh.factory<_i635.RegisterUserUsecase>(
        () => _i635.RegisterUserUsecase(gh<_i754.AuthRepository>()));
    gh.factory<_i832.AuthController>(() => _i832.AuthController(
          gh<_i591.SendOtpUseCase>(),
          gh<_i635.RegisterUserUsecase>(),
        ));
    return this;
  }
}

class _$NetworkModule extends _i184.NetworkModule {}
