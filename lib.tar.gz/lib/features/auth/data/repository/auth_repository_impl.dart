import 'package:dartz/dartz.dart';
import 'package:escooter/core/error/api_exceptions.dart';
import 'package:escooter/features/auth/data/models/otp_response.dart';
import 'package:escooter/features/auth/data/sources/auth_service.dart';
import 'package:escooter/features/auth/domain/entities/create_user_request.dart';
import 'package:escooter/features/auth/domain/repository/auth_repository.dart';
import 'package:escooter/utils/logger.dart';
import 'package:injectable/injectable.dart';

@Injectable(as: AuthRepository)
class AuthRepositoryImpl implements AuthRepository {
  final AuthApiService _authApiService;

  AuthRepositoryImpl(@Named('authApiService') this._authApiService);

  @override
  Future<Either<AuthException, OtpResponse>> sendOtp(String phoneNumber) async {
    try {
      final result = await _authApiService.sendOtp(phoneNumber);
      return result.fold(
        // Handle API error
        (apiException) => Left(AuthException(apiException.message)),
        (json) {
          try {
            final otpResponse = OtpResponse.fromJson(json);
            return Right(otpResponse);
          } catch (e) {
            // Handle parsing errors
            return Left(AuthException('Invalid response'));
          }
        },
      );
    } catch (e) {
      return Left(AuthException('Unexpected error'));
    }
  }

  @override
  Future<Either> verifyOtp(String phoneNumber, String otp) {
    // TODO: implement verifyOtp
    throw UnimplementedError();
  }

  @override
  Future<Either<AuthException, String>> registerUser(
      CreateUserRequest createUserRequest) async {
    try {
      final result = await _authApiService.registerUser(createUserRequest);
      return result.fold(
        (apiException) {
          AppLogger.log(
              "From auth repository implementation: ${apiException.message}");
          AppLogger.error(apiException.message);
          return Left(AuthException(apiException.message));
        },
        (json) {
          try {
            AppLogger.log(json['message']);
            return Right(json['message']);
          } catch (e) {
            AppLogger.error('Invalid response');
            return Left(AuthException('Invalid response'));
          }
        },
      );
    } catch (e) {
      AppLogger.error('Unexpected error: $e');
      return Left(AuthException('Unexpected error: $e'));
    }
  }
}
