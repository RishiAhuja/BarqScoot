import 'package:dartz/dartz.dart';
import 'package:escooter/features/auth/domain/entities/create_user_request.dart';

abstract class AuthRepository {
  Future<Either> registerUser(CreateUserRequest phoneNumber);
  Future<Either> sendOtp(String phoneNumber);
  Future<Either> verifyOtp(String phoneNumber, String otp);
}
