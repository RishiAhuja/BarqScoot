// lib/presentation/auth/providers/auth_providers.dart
import 'package:escooter/core/di/service_locator/service_locator.dart';
import 'package:escooter/features/auth/domain/entities/create_user_request.dart';
import 'package:escooter/features/auth/domain/usecases/register_user_usecase.dart';
import 'package:escooter/features/auth/domain/usecases/sent_otp_usecase.dart';
import 'package:escooter/utils/logger.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:injectable/injectable.dart';

enum AuthMode { login, register }

final authModeProvider = StateProvider<AuthMode>((ref) => AuthMode.login);

@injectable
class AuthController extends StateNotifier<AsyncValue<void>> {
  final SendOtpUseCase _sendOtpUseCase;
  final RegisterUserUsecase _registerUserUsecase;

  AuthController(this._sendOtpUseCase, this._registerUserUsecase)
      : super(const AsyncValue.data(null));

  Future<void> sendOTP(String phoneNumber, BuildContext context) async {
    state = const AsyncValue.loading();
    try {
      final result = await _sendOtpUseCase(params: phoneNumber);

      result.fold((l) {
        state = AsyncValue.error(l, StackTrace.current);
      }, (r) {
        state = const AsyncValue.data(null);
        if (context.mounted) {
          context.push('/auth/otp', extra: {'phoneNumber': phoneNumber});
        }
      });
    } catch (e) {
      state = AsyncValue.error(e, StackTrace.current);
    }
  }

  Future<void> registerUserBackdoor(
      CreateUserRequest createUserRequest, BuildContext context) async {
    state = const AsyncValue.loading();
    Future.delayed(Duration(seconds: 2));
    context.push('/auth/otp',
        extra: {'phoneNumber': createUserRequest.phoneNumber});
  }

  Future<void> registerUser({
    required CreateUserRequest createUserRequest,
    required BuildContext context,
    required bool useBackdoor,
  }) async {
    state = const AsyncValue.loading();

    if (useBackdoor) {
      return registerUserBackdoor(createUserRequest, context);
    } else {
      try {
        final result = await _registerUserUsecase(params: createUserRequest);

        result.fold((l) {
          AppLogger.error(l);
          state = AsyncValue.error(l, StackTrace.current);
        }, (r) {
          AppLogger.log(r);
          state = const AsyncValue.data(null);

          if (context.mounted) {
            context.push('/auth/otp',
                extra: {'phoneNumber': createUserRequest.phoneNumber});
          }
        });
      } catch (e) {
        state = AsyncValue.error(e, StackTrace.current);
      }
    }
  }
}

// Provider now uses GetIt to create the controller
final authControllerProvider =
    StateNotifierProvider<AuthController, AsyncValue<void>>((ref) {
  return getIt<AuthController>();
});
