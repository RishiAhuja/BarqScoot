import 'package:escooter/common/router/app_router.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final otpVerificationProvider =
    StateNotifierProvider<OtpVerificationNotifier, AsyncValue<void>>((ref) {
  return OtpVerificationNotifier();
});

class OtpVerificationNotifier extends StateNotifier<AsyncValue<void>> {
  OtpVerificationNotifier() : super(const AsyncValue.data(null));

  Future<void> verifyOtp(String otp, BuildContext context) async {
    state = const AsyncValue.loading();
    try {
      // Add your OTP verification logic here
      await Future.delayed(const Duration(seconds: 2));
      state = const AsyncValue.data(null);
      // On success, you might want to update the auth state
      context
          .authenticateAndRedirect(); // Use the extension method we created earlier
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }
}
