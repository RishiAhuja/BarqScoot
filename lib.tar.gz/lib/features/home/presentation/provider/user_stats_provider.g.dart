// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_stats_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$userStatsNotifierHash() => r'24b90728726b1eebdab12f961f1f6ed03b41c4f0';

/// See also [UserStatsNotifier].
@ProviderFor(UserStatsNotifier)
final userStatsNotifierProvider =
    AutoDisposeAsyncNotifierProvider<UserStatsNotifier, UserStats>.internal(
  UserStatsNotifier.new,
  name: r'userStatsNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$userStatsNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UserStatsNotifier = AutoDisposeAsyncNotifier<UserStats>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
