// First, let's create a custom class to represent bottom navigation items
import 'package:escooter/common/router/app_router.dart';
import 'package:escooter/common/widgets/drawer/app_drawer.dart';
import 'package:escooter/core/configs/theme/app_styles.dart';
import 'package:escooter/features/home/presentation/widgets/bottom_sheet_content.dart';
import 'package:escooter/features/home/presentation/widgets/map_view.dart';
import 'package:escooter/features/home/presentation/widgets/search_modal.dart';
import 'package:escooter/features/notifications/presentation/modals/notification_modal.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

class BottomNavItem {
  final IconData icon;
  final String label;
  final String path;
  final String semanticLabel;

  const BottomNavItem({
    required this.icon,
    required this.label,
    required this.path,
    required this.semanticLabel,
  });
}

class HomeScreen extends ConsumerWidget {
  // Define bottom navigation items
  final List<BottomNavItem> _navItems = const [
    BottomNavItem(
      icon: Icons.history,
      label: 'History',
      path: AppPaths.rideHistory,
      semanticLabel: 'Ride History',
    ),
    BottomNavItem(
      icon: Icons.electric_scooter,
      label: 'Rides',
      path: AppPaths.activeRide,
      semanticLabel: 'Active Ride',
    ),
    BottomNavItem(
      icon: Icons.account_balance_wallet,
      label: 'Wallet',
      path: AppPaths.wallet,
      semanticLabel: 'Wallet',
    ),
    BottomNavItem(
      icon: Icons.person,
      label: 'Profile',
      path: AppPaths.profile,
      semanticLabel: 'User Profile',
    ),
  ];

  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Get screen size for responsive layout
    final screenSize = MediaQuery.of(context).size;
    final theme = Theme.of(context);

    return Scaffold(
      drawer: const AppDrawer(),
      appBar: AppBar(
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none_outlined),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (_) => const NotificationModal(),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                builder: (_) => const SearchModal(),
              );
            },
          ),
        ],
      ),
      body: SizedBox(
        height: screenSize.height,
        width: screenSize.width,
        child: Stack(
          fit: StackFit.expand,
          children: [
            const Positioned.fill(
              child: MapView(),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                constraints: BoxConstraints(
                  maxHeight: screenSize.height * 0.7,
                ),
                child: const BottomSheetContent(),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomBar(context, theme),
      // bottomNavigationBar: BottomAppBar(
      //   elevation: 0,
      //   child: Padding(
      //     padding: const EdgeInsets.symmetric(horizontal: 16.0),
      //     child: Row(
      //       mainAxisAlignment: MainAxisAlignment.spaceAround,
      //       children: [
      //         // Left side navigation items
      //         _buildNavItem(context, _navItems[0], theme),
      //         _buildNavItem(context, _navItems[1], theme),
      //         // Center space for FAB
      //         const SizedBox(width: 80),
      //         // Right side navigation items
      //         _buildNavItem(context, _navItems[2], theme),
      //         _buildNavItem(context, _navItems[3], theme),
      //       ],
      //     ),
      //   ),
      // ),
      floatingActionButton: SizedBox(
        width: 64, // Larger width
        height: 64,
        child: FloatingActionButton(
          elevation: 0,
          shape: const CircleBorder(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.qr_code_scanner),
            ],
          ),
          onPressed: () {
            context.go(AppPaths.scanner);
          },
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }

  // Helper method to build navigation items
  Widget _buildNavItem(
      BuildContext context, BottomNavItem item, ThemeData theme) {
    return InkWell(
      onTap: () => context.push(item.path),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              item.icon,
              size: 24,
              semanticLabel: item.semanticLabel,
            ),
            const SizedBox(height: 4),
            Text(
              item.label,
              style: theme.textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context, ThemeData theme) {
    return BottomAppBar(
      height: kBottomNavigationBarHeight + 35,
      elevation: 8,
      notchMargin: 8,
      shape: const CircularNotchedRectangle(),
      child: Container(
        height: 60,
        padding: const EdgeInsets.symmetric(horizontal: AppStyles.spacing),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            ..._navItems
                .take(2)
                .map((item) => _buildNavItem(context, item, theme)),
            const SizedBox(width: 80),
            ..._navItems
                .skip(2)
                .map((item) => _buildNavItem(context, item, theme)),
          ],
        ),
      ),
    );
  }
}
