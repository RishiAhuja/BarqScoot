import 'package:escooter/core/configs/theme/app_colors.dart';
import 'package:escooter/features/home/presentation/provider/scooter_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../provider/user_stats_provider.dart';

class BottomSheetContent extends ConsumerWidget {
  const BottomSheetContent({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statsAsync = ref.watch(userStatsNotifierProvider);
    final scootersAsync = ref.watch(scootersNotifierProvider);

    return DraggableScrollableSheet(
      initialChildSize: 0.3,
      minChildSize: 0.2,
      maxChildSize: 0.9,
      builder: (context, scrollController) => Container(
        decoration: BoxDecoration(
          color: AppColors.backgroundColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: ListView(
          controller: scrollController,
          children: [
            const SizedBox(height: 12),
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            statsAsync.when(
              data: (stats) => Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _StatItem(
                      title: 'Total Rides',
                      value: '${stats.totalRides}',
                      icon: Icons.history,
                    ),
                    _StatItem(
                      title: 'Balance',
                      value: '﷼${stats.balance}',
                      icon: Icons.account_balance_wallet,
                    ),
                  ],
                ),
              ),
              loading: () => const CircularProgressIndicator(),
              error: (_, __) => const Text('Error loading stats'),
            ),
            // Nearby scooters list
            scootersAsync.when(
              data: (scooters) => ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: scooters.length,
                itemBuilder: (context, index) => ListTile(
                  onTap: () {},
                  leading: const Icon(Icons.electric_scooter),
                  title: Text('Scooter ${scooters[index].id}'),
                  subtitle: Text('${scooters[index].distance}km away'),
                  trailing: Text('${scooters[index].batteryLevel}%'),
                ),
              ),
              loading: () => const CircularProgressIndicator(),
              error: (_, __) => const Text('Error loading scooters'),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatItem extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _StatItem({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon),
        const SizedBox(height: 8),
        Text(value, style: Theme.of(context).textTheme.headlineSmall),
        Text(title, style: Theme.of(context).textTheme.bodyLarge),
      ],
    );
  }
}
