import 'package:escooter/features/ride_history/presentation/widgets/ride_history_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class RideHistoryScreen extends ConsumerWidget {
  const RideHistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // final theme = Theme.of(context);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Ride History',
            style: Theme.of(context)
                .textTheme
                .displayMedium
                ?.copyWith(fontWeight: FontWeight.w200, fontSize: 20)),
        // actions: [
        //   IconButton(
        //     icon: const Icon(Icons.filter_list),
        //     onPressed: () {
        //       // TODO: Show filter options
        //     },
        //   ),
        // ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: 10, // Replace with actual ride history
        itemBuilder: (context, index) {
          return RideHistoryCard(
            date: DateTime.now().subtract(Duration(days: index)),
            startLocation: '123 Main St',
            endLocation: '456 Park Ave',
            duration: const Duration(minutes: 15),
            cost: 5.99,
            onTap: () {},
          );
        },
      ),
    );
  }
}
