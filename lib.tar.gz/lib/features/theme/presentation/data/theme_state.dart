enum ThemeState {
  light,
  dark;

  bool get isDark => this == ThemeState.dark;
}
